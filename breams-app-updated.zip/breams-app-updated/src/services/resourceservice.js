import axios from 'axios';
const USERS_REST_API_URL="http://localhost:8080/api/resources";
class ResourceService{
   static getResources(){
       return axios.get(`${USERS_REST_API_URL}/all`);
    }
    
    static getResourceById(userId)
    {
        return axios.get(USERS_REST_API_URL+'/get/'+userId);
    }

}
export default  ResourceService;