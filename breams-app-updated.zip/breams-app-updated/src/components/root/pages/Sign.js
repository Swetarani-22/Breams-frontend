import React from 'react';
// import '../CSS/sign-in.css';

class SignIn extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            email: '',
            password: ''
        }
    }

    handleSubmit = event => {
        event.preventDefault();

        this.setState({ email: '', password: '' });
    }

    handleChange = (event) => {
        const { value, name } = event.target;

        this.setState({ [name]: value });
    }

    render() {
        return (
            <div class="container">
                <h2>Sign In Form</h2>

                <form onSubmit={this.handleSubmit}>
                    
          <div class="form-group">
            <label>Email</label>
                    <input  name='email' type='email' class="form-control" value={this.state.email} required handleChange={this.handleChange} label='email' />
</div>

<div class="form-group">
            <label>Password</label>
                    <input name='password' type='password' class="form-control" value={this.state.password} required handleChange={this.handleChange} label='password' />
</div>
                   <button class="btn btn-info">SUBMIT</button>
                </form>

            </div>
        );
    }
}

export default SignIn;