import React from 'react';
import ResourceService from '../../../services/resourceservice';
class Booknew extends React.Component {
    constructor(props){
        super(props)
            this.state={
                books:[]
             
               
            }
        }
        // componentDidMount(){
        //     fetch("http://localhost:8080/api/resources/all")
        //     .then((res)=> res.json())
        //     .then((json)=>{
        //         this.setState({
        //             books:json,
        //             DataisLoaded:true
        //         })
        //     })
           
                        
                    
        //             }
                    componentDidMount(){
                        ResourceService.getResources().then(res=> this.setState({books:res.data}));
                    
                        }

                    reserveResource=(id)=>{
                        this.props.history.push(`/view-resource/${id}`);
                    }
                  
        render() {
            return (
<div>
    <h2 style={{fontWeight: "bold"}}>BOOKS</h2>
<table className='table table-striped'>
                <thead>
                    <tr>
                        <td>ID</td>
                        <td>AUTHOR</td>
                        <td>EDITORIASL</td>
                
                        <td></td>
                    </tr>
                </thead>
                <tbody>
                    {
                        this.state.books.map(
                            books=>
                            <tr key={books.id}>
                            <td style={{fontWeight: "bold"}}>{books.id}</td>
                            <td style={{fontWeight: "bold"}}>{books.author}</td>
                            <td style={{fontWeight: "bold"}}>{books.editorial}</td>
                            <td style={{fontWeight: "bold"}}>{books.email}</td>
                            <td>
                  
                          
                  
                  {/* <button class="btn btn-primary mr-2" onClick={this.delete(users.id)}>Delete</button> */}
                  
    
                     <button onClick={ () => this.reserveResource(books.id)} className="btn btn-info" >Reserve </button>
                    
                   
                </td>
                {/* <td>
                  <Link class="btn btn-primary mr-2" to={`/users/${users.id}`}>
                    View
                  </Link>
                  </td> */}
                 

                            </tr>

                        )                    }
                </tbody>

            </table>


        </div>



            )
            
            }
        
        }
        export default Booknew;