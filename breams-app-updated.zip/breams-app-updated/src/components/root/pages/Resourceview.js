import React from 'react';
import ResourceService from '../../../services/resourceservice';
import story from '../layout/assets/peter.jpg';

// import {Link} from "react-router-dom";
class Resourceview extends React.Component{
 
constructor(props){
super(props)
    this.state={
        id: this.props.match.params.id,
        book: {}
     
       
    }
  
    
}
componentDidMount(){
    ResourceService.getResourceById(this.state.id).then( res => {
        this.setState({book: res.data});
    })
}
Redirect(){
    this.props.history.push('/sign-in');
}

render()
{ return (
    <div>
        <br></br>
                <div className = "card col-md-6 offset-md-3">
                    <h3 className = "text-center"> View  Details</h3>
                    <div className = "card-body">
                        {/* <div className = "row"> */}
                            <label> Title: </label>
                            <div> { this.state.book.title }</div>
                            <img src={story} alt="logo"/>
                            <div> { this.state.book.picture }</div>
                        {/* </div> */}
                        <div className = "row">
                            <label> PRICE IN RS: </label>
                            {/* <div> { this.state.user.lastName }</div> */}
                        </div>
                        <div className = "row">
                            <label>1288/-: </label>
                            {/* <div> { this.state.user.email }</div> */}
                        </div>
                        <div>
                        <button onClick={ () => this.Redirect()} className="btn btn-info" >Reserve Now </button>
                        </div>
                    </div>

                </div>
    // </div>
)
}
}
export default Resourceview;